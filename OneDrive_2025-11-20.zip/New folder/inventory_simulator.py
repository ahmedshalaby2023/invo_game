"""Inventory replenishment and consumption simulator with animated scene."""

from __future__ import annotations

import math
import tkinter as tk
from tkinter import ttk


class InventorySimulatorApp:
    """Interactive inventory simulator with animated logistics scene."""

    UPDATE_INTERVAL_MS = 120
    SIM_MINUTES_PER_DAY = 1.0
    TRUCK_LOADING_PORTION = 0.25

    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title("Shalaby Inventory Simulator")
        self.root.configure(bg="#eef3fb")

        self._init_style()
        self._init_variables()
        self._init_layout()
        self.base_minutes_per_tick = self.UPDATE_INTERVAL_MS / 60000.0
        self.minutes_per_step = self.base_minutes_per_tick
        self.reset_simulation_state()

        self.update_parameter_labels()
        self.draw_scene()
        self.schedule_update()

    # ------------------------------------------------------------------
    # UI setup
    # ------------------------------------------------------------------
    def _init_style(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#eef3fb")
        style.configure("TLabel", background="#eef3fb", font=("Segoe UI", 10))
        style.configure("Headline.TLabel", font=("Segoe UI Semibold", 13))
        style.configure("Alert.TLabel", font=("Segoe UI", 11))
        style.configure("TButton", font=("Segoe UI", 10))

    def _init_variables(self) -> None:
        self.lead_time_var = tk.DoubleVar(value=6.0)
        self.moq_var = tk.IntVar(value=160)
        self.consumption_var = tk.DoubleVar(value=180.0)
        self.safety_stock_var = tk.IntVar(value=180)
        self.factory_batch_var = tk.IntVar(value=40)
        self.scenario_var = tk.StringVar(value="Accurate forecast")
        self.scenario_options = ("Accurate forecast", "Biased forecast")
        self.consumption_unit_var = tk.StringVar(value="minute")
        self.alert_var = tk.StringVar(value="")
        self.lead_time_label = tk.StringVar()
        self.moq_label = tk.StringVar()
        self.consumption_label = tk.StringVar()
        self.reorder_point_label = tk.StringVar()
        self.supplier_stock_label = tk.StringVar()
        self.safety_stock_label = tk.StringVar()
        self.factory_batch_label = tk.StringVar()
        self.time_scale_label = tk.StringVar()

        self.score = 0.0
        self.best_score = 0.0
        self.last_score = 0.0
        self.score_steps = 0
        self.run_count = 0

    def _init_layout(self) -> None:
        controls = ttk.Frame(self.root, padding=(16, 12))
        controls.pack(fill=tk.X)

        ttk.Label(controls, text="Simulation Parameters", style="Headline.TLabel").grid(
            row=0, column=0, columnspan=12, sticky="w", pady=(0, 10)
        )

        self._add_scale(
            controls,
            label="Lead Time (days)",
            var=self.lead_time_var,
            text_var=self.lead_time_label,
            column=0,
            from_=1,
            to=14,
            resolution=0.5,
        )
        self._add_scale(
            controls,
            label="MOQ (units)",
            var=self.moq_var,
            text_var=self.moq_label,
            column=2,
            from_=40,
            to=400,
            resolution=10,
        )
        self.consumption_frame = ttk.Frame(controls)
        self.consumption_frame.grid(row=1, column=4, sticky="w", padx=(0, 12))
        ttk.Label(self.consumption_frame, text="Consumption Rate (units/day)").pack(anchor="w")
        tk.Scale(
            self.consumption_frame,
            from_=20,
            to=320,
            resolution=5,
            orient=tk.HORIZONTAL,
            showvalue=False,
            variable=self.consumption_var,
            length=160,
            command=lambda _evt: self.update_parameter_labels(),
        ).pack(anchor="w")
        unit_switch = ttk.Combobox(
            self.consumption_frame,
            textvariable=self.consumption_unit_var,
            values=("minute", "second"),
            state="readonly",
            width=10,
        )
        unit_switch.pack(anchor="w", pady=(2, 2))
        unit_switch.bind("<<ComboboxSelected>>", lambda _evt: self.update_parameter_labels())
        ttk.Label(self.consumption_frame, textvariable=self.consumption_label).pack(anchor="w", pady=(2, 2))
        ttk.Label(self.consumption_frame, textvariable=self.time_scale_label).pack(anchor="w", pady=(0, 4))

        self.reorder_frame = ttk.Frame(controls)
        self.reorder_frame.grid(row=1, column=6, sticky="w", padx=(0, 12))
        ttk.Label(self.reorder_frame, text="Reorder Point (auto)").pack(anchor="w")
        ttk.Label(self.reorder_frame, textvariable=self.reorder_point_label).pack(anchor="w", pady=(2, 4))

        self._add_scale(
            controls,
            label="Safety Stock (units)",
            var=self.safety_stock_var,
            text_var=self.safety_stock_label,
            column=8,
            from_=60,
            to=360,
            resolution=10,
        )
        self._add_scale(
            controls,
            label="Factory Batch (units)",
            var=self.factory_batch_var,
            text_var=self.factory_batch_label,
            column=10,
            from_=20,
            to=120,
            resolution=5,
        )

        button_frame = ttk.Frame(self.root, padding=(16, 0, 16, 12))
        button_frame.pack(fill=tk.X)

        ttk.Label(button_frame, text="Scenario:").pack(side=tk.LEFT, padx=(0, 6))
        self.scenario_combo = ttk.Combobox(
            button_frame,
            textvariable=self.scenario_var,
            values=self.scenario_options,
            state="readonly",
            width=20,
        )
        self.scenario_combo.pack(side=tk.LEFT)
        self.scenario_combo.bind("<<ComboboxSelected>>", lambda _evt: self.handle_scenario_change())

        ttk.Separator(button_frame, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=12, pady=4)

        self.start_button = ttk.Button(button_frame, text="Start", command=self.toggle_start)
        self.start_button.pack(side=tk.LEFT)

        ttk.Button(button_frame, text="Reset", command=self.reset_simulation_state).pack(
            side=tk.LEFT, padx=(8, 0)
        )

        ttk.Button(button_frame, text="Step", command=self.single_step).pack(
            side=tk.LEFT, padx=(8, 0)
        )

        self.canvas = tk.Canvas(self.root, width=940, height=420, bg="#f7f9ff", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 8))

        self.alert_label = ttk.Label(
            self.root,
            textvariable=self.alert_var,
            style="Alert.TLabel",
            anchor="center",
            justify="center",
            foreground="#2e7d32",
        )
        self.alert_label.pack(fill=tk.X, padx=16, pady=(0, 16))

    def _add_scale(
        self,
        parent: ttk.Frame,
        *,
        label: str,
        var: tk.Variable,
        text_var: tk.StringVar,
        column: int,
        from_: float,
        to: float,
        resolution: float,
    ) -> None:
        frame = ttk.Frame(parent)
        frame.grid(row=1, column=column, sticky="w", padx=(0, 12))
        ttk.Label(frame, text=label).pack(anchor="w")
        tk.Scale(
            frame,
            from_=from_,
            to=to,
            resolution=resolution,
            orient=tk.HORIZONTAL,
            showvalue=False,
            variable=var,
            length=160,
            command=lambda _evt: self.update_parameter_labels(),
        ).pack(anchor="w")
        ttk.Label(frame, textvariable=text_var).pack(anchor="w", pady=(2, 4))

    # ------------------------------------------------------------------
    # Simulation lifecycle
    # ------------------------------------------------------------------
    def reset_simulation_state(self) -> None:
        self.factory_stock = 240.0
        self.warehouse_stock = 520.0
        self.supplier_stock = 1000.0
        self.safety_stock = float(self.safety_stock_var.get())
        self.high_stock_threshold = 800.0
        self.worker_capacity = max(1.0, float(self.factory_batch_var.get()))
        self.worker_progress = 0.0
        self.worker_direction = 1
        self.worker_load = 0.0

        self.truck_en_route = False
        self.truck_progress = 0.0
        self.truck_delivery = 0.0
        self.truck_wait_timer = 0.0
        self.truck_travel_minutes_total = 0.0
        self.truck_travel_minutes_remaining = 0.0

        self.production_shutdown = False
        self.extra_storage_cost = 0.0
        self.score = 0.0
        self.score_steps = 0
        self.running = False
        self.start_button.configure(text="Start")
        self.alert_var.set("Press Start to run the simulator.")
        self.alert_label.configure(foreground="#2e7d32")
        self.update_parameter_labels()
        self.draw_scene()

    def toggle_start(self) -> None:
        self.running = not self.running
        self.start_button.configure(text="Pause" if self.running else "Start")
        if self.running:
            self.score = 0.0
            self.score_steps = 0
            self.run_count += 1
            self.alert_var.set(f"{self.scenario_var.get()} scenario running...")
            self.alert_label.configure(foreground="#2e7d32")
        else:
            self.last_score = self.score
            self.best_score = max(self.best_score, self.score)

    def single_step(self) -> None:
        if not self.running:
            self.update_simulation()

    def schedule_update(self) -> None:
        self.root.after(self.UPDATE_INTERVAL_MS, self._tick)

    def _tick(self) -> None:
        if self.running:
            self.update_simulation()
        self.schedule_update()

    def update_simulation(self) -> None:
        self.apply_consumption()
        self.move_worker()
        self.handle_replenishment()
        self.move_truck()
        self.apply_scenario_effects()
        self.update_score()
        self.update_alerts()
        self.draw_scene()

    # ------------------------------------------------------------------
    # Parameter helpers
    # ------------------------------------------------------------------
    def update_parameter_labels(self) -> None:
        self.lead_time_label.set(f"{self.lead_time_var.get():.1f} d")
        self.moq_label.set(f"{self.moq_var.get()} units")
        self.consumption_label.set(f"{self.consumption_var.get():.0f} units/day")
        self._update_time_scaling()

        self.safety_stock = float(self.safety_stock_var.get())
        self.worker_capacity = max(1.0, float(self.factory_batch_var.get()))
        self.safety_stock_label.set(f"{self.safety_stock_var.get()} units")
        self.factory_batch_label.set(f"{self.factory_batch_var.get()} units")

        reorder_point = self.compute_reorder_point()
        self.reorder_point_label.set(f"{int(reorder_point):,} units")
        self.supplier_stock_label.set(f"{int(self.supplier_stock):,} units")

    def _update_time_scaling(self) -> None:
        unit = self.consumption_unit_var.get()
        if unit == "second":
            factor = 60.0
            self.time_scale_label.set("Sim speed: 1 day = 1 sec (x60)")
        else:
            factor = 1.0
            self.time_scale_label.set("Sim speed: 1 day = 1 min (x1)")
        self.minutes_per_step = self.base_minutes_per_tick * factor

    def handle_scenario_change(self) -> None:
        self.production_shutdown = False
        self.extra_storage_cost = 0.0
        self.running = False
        self.start_button.configure(text="Start")
        self.alert_var.set(f"{self.scenario_var.get()} scenario ready. Press Start.")
        self.alert_label.configure(foreground="#2e7d32")
        self.update_parameter_labels()
        self.draw_scene()

    def get_consumption_multiplier(self) -> float:
        scenario = self.scenario_var.get()
        if scenario == "Biased forecast":
            return 1.6
        return 1.0

    def apply_consumption(self) -> None:
        if self.production_shutdown:
            return
        per_minute = self.compute_consumption_per_minute()
        per_step = per_minute * self.minutes_per_step
        self.factory_stock = max(0.0, self.factory_stock - per_step)

    def compute_consumption_per_minute(self) -> float:
        daily_rate = max(0.0, float(self.consumption_var.get()))
        per_minute = daily_rate / max(1.0, self.SIM_MINUTES_PER_DAY)
        return per_minute * self.get_consumption_multiplier()

    def compute_worker_speed(self) -> float:
        per_minute = self.compute_consumption_per_minute()
        capacity = max(0.0, self.worker_capacity)
        if capacity <= 0:
            return 0.0

        half_trip_minutes: float | None = None
        if per_minute > 0:
            trips_per_minute = per_minute / capacity
            if trips_per_minute > 0:
                cycle_minutes = 1.0 / trips_per_minute
                half_trip_minutes = max(self.minutes_per_step, cycle_minutes / 2.0)
        else:
            if self.worker_direction == -1 and self.worker_progress > 0.0:
                half_trip_minutes = 0.5
            elif self.worker_direction == 1 and self.worker_progress < 1.0:
                half_trip_minutes = 0.5

        if half_trip_minutes is None or not math.isfinite(half_trip_minutes) or half_trip_minutes <= 0.0:
            return 0.0

        progress = self.minutes_per_step / half_trip_minutes
        return max(0.0, min(1.0, progress))

    def compute_truck_speed(self) -> float:
        if self.truck_travel_minutes_total <= 0:
            return 1.0
        progress = self.minutes_per_step / self.truck_travel_minutes_total
        return max(0.0, min(1.0, progress))

    def compute_reorder_point(self) -> float:
        lead_time_days = max(0.0, float(self.lead_time_var.get()))
        consumption_per_minute = self.compute_consumption_per_minute()
        lead_time_minutes = lead_time_days * self.SIM_MINUTES_PER_DAY
        lead_time_demand = consumption_per_minute * lead_time_minutes
        reorder_point = self.safety_stock + lead_time_demand
        return max(0.0, reorder_point)

    # ------------------------------------------------------------------
    # Simulation mechanics
    # ------------------------------------------------------------------
    def move_worker(self) -> None:
        speed = self.compute_worker_speed()
        if self.worker_direction == 1:
            if self.worker_progress < 1.0:
                self.worker_progress = min(1.0, self.worker_progress + speed)
            if math.isclose(self.worker_progress, 1.0, abs_tol=1e-3):
                if self.warehouse_stock > 0:
                    take_amount = min(self.worker_capacity, self.warehouse_stock)
                    self.worker_load = take_amount
                    self.warehouse_stock -= take_amount
                    self.worker_direction = -1
                else:
                    self.worker_load = 0.0
                    self.worker_direction = -1
        else:
            if self.worker_progress > 0.0:
                self.worker_progress = max(0.0, self.worker_progress - speed)
            if math.isclose(self.worker_progress, 0.0, abs_tol=1e-3):
                if self.worker_load > 0:
                    self.factory_stock += self.worker_load
                    self.worker_load = 0.0
                self.worker_direction = 1

    def handle_replenishment(self) -> None:
        if self.truck_en_route:
            return
        reorder_point = self.compute_reorder_point()
        if self.warehouse_stock <= reorder_point:
            self.truck_en_route = True
            self.truck_progress = 0.0
            lead_time_days = max(0.1, float(self.lead_time_var.get()))
            lead_time_minutes = lead_time_days * self.SIM_MINUTES_PER_DAY
            loading_minutes = lead_time_minutes * self.TRUCK_LOADING_PORTION
            travel_minutes = max(self.minutes_per_step, lead_time_minutes - loading_minutes)
            self.truck_wait_timer = loading_minutes
            self.truck_travel_minutes_total = travel_minutes
            self.truck_travel_minutes_remaining = travel_minutes
            request_amount = max(20.0, float(self.moq_var.get()))
            self.truck_delivery = min(request_amount, self.supplier_stock)
            self.supplier_stock -= self.truck_delivery

    def move_truck(self) -> None:
        if not self.truck_en_route:
            return

        if self.truck_wait_timer > 0:
            self.truck_wait_timer = max(0.0, self.truck_wait_timer - self.minutes_per_step)
            if self.truck_wait_timer > 0:
                return

        if self.truck_travel_minutes_total <= 0:
            self._complete_truck_delivery()
            return

        self.truck_travel_minutes_remaining = max(
            0.0, self.truck_travel_minutes_remaining - self.minutes_per_step
        )
        self.truck_progress = min(1.0, self.truck_progress + self.compute_truck_speed())

        if (
            self.truck_travel_minutes_remaining <= 0.0
            or math.isclose(self.truck_progress, 1.0, abs_tol=1e-3)
        ):
            self._complete_truck_delivery()

    def _complete_truck_delivery(self) -> None:
        if self.truck_delivery > 0:
            self.warehouse_stock += self.truck_delivery
        self.truck_en_route = False
        self.truck_progress = 0.0
        self.truck_delivery = 0.0
        self.truck_wait_timer = 0.0
        self.truck_travel_minutes_total = 0.0
        self.truck_travel_minutes_remaining = 0.0

    def apply_scenario_effects(self) -> None:
        scenario = self.scenario_var.get()
        if scenario == "Biased forecast":
            if self.factory_stock < max(40.0, self.safety_stock * 0.5):
                self.production_shutdown = True
            if self.production_shutdown and self.factory_stock > self.safety_stock + 60:
                self.production_shutdown = False
        else:
            self.production_shutdown = False
            self.extra_storage_cost = 0.0

    # ------------------------------------------------------------------
    # Alerts
    # ------------------------------------------------------------------
    def update_score(self) -> None:
        if not self.running:
            return

        step_score = 0

        if self.production_shutdown:
            step_score -= 1
        else:
            step_score += 1  # production online

        if self.factory_stock <= 0:
            step_score -= 1
        elif self.factory_stock < self.safety_stock:
            step_score -= 1

        if self.warehouse_stock <= 0:
            step_score -= 1
        elif self.warehouse_stock < self.safety_stock:
            step_score -= 1

        reorder_point = self.compute_reorder_point()
        if self.warehouse_stock >= reorder_point:
            step_score += 1

        self.score += step_score
        self.score_steps += 1

    def update_alerts(self) -> None:
        alerts: list[str] = []
        if self.factory_stock < self.safety_stock:
            alerts.append("Factory stock below safety stock!")
        if self.warehouse_stock < self.safety_stock:
            alerts.append("Warehouse stock critically low!")
        if self.warehouse_stock > self.high_stock_threshold:
            alerts.append("Warehouse stock is too high!")

        scenario = self.scenario_var.get()
        if self.production_shutdown:
            alerts.append("Production shutdown triggered!")
        if scenario == "Biased forecast" and not self.production_shutdown and self.factory_stock < self.safety_stock:
            alerts.append("Factory stock dropping fast under biased forecast scenario!")

        if alerts:
            self.alert_var.set("\n".join(alerts))
            self.alert_label.configure(foreground="#c62828")
        else:
            healthy_msg = "Stock levels are healthy."
            if scenario != "Accurate forecast":
                healthy_msg = f"{scenario} scenario stable." 
            self.alert_var.set(healthy_msg)
            self.alert_label.configure(foreground="#2e7d32")

    # ------------------------------------------------------------------
    # Drawing helpers
    # ------------------------------------------------------------------
    def draw_scene(self) -> None:
        self.canvas.delete("all")
        self._draw_background()
        self._draw_facilities()
        self._draw_stocks()
        self._draw_paths()
        self._draw_worker()
        self._draw_truck()
        self._draw_score_panel()

    def _draw_background(self) -> None:
        self.canvas.create_rectangle(0, 0, 1100, 420, fill="#f7f9ff", outline="")
        self.canvas.create_text(
            30,
            30,
            text="Shalaby",
            anchor="w",
            font=("Montserrat", 28, "bold"),
            fill="#005bbb",
        )
        self.canvas.create_text(
            32,
            68,
            text="inventory playground",
            anchor="w",
            font=("Segoe UI", 11),
            fill="#5f6d7a",
        )

    def _draw_facilities(self) -> None:
        self.factory_coords = (90, 220, 220, 360)
        self.warehouse_coords = (380, 190, 540, 360)
        self.supplier_coords = (690, 220, 870, 360)

        self.canvas.create_rectangle(*self.factory_coords, fill="#c8e6c9", outline="#81c784", width=2)
        self.canvas.create_rectangle(*self.warehouse_coords, fill="#ffe0b2", outline="#ffb74d", width=2)
        self._draw_supermarket()

        self.canvas.create_text(155, 372, text="Factory", font=("Segoe UI", 12, "bold"), fill="#33691e")
        self.canvas.create_text(460, 372, text="Warehouse", font=("Segoe UI", 12, "bold"), fill="#ef6c00")
        self.canvas.create_text(880, 372, text="Market", font=("Segoe UI", 12, "bold"), fill="#1e88e5")

    def _draw_supermarket(self) -> None:
        sx0, sy0, sx1, sy1 = self.supplier_coords
        facade_fill = "#fff3e0"
        outline = "#ffb74d"
        roof_height = 36

        self.canvas.create_polygon(
            (sx0 - 12, sy0),
            ((sx0 + sx1) / 2, sy0 - roof_height),
            (sx1 + 12, sy0),
            fill="#ff8a65",
            outline="#f4511e",
            width=2,
        )

        self.canvas.create_rectangle(sx0, sy0, sx1, sy1, fill=facade_fill, outline=outline, width=2)

        awning_height = 22
        awning_y0 = sy0 + 12
        awning_y1 = awning_y0 + awning_height
        stripe_width = 14
        colors = ("#ff7043", "#ffe082")
        stripe_index = 0
        x = sx0 + 8
        while x < sx1 - 8:
            stripe_fill = colors[stripe_index % len(colors)]
            self.canvas.create_rectangle(x, awning_y0, min(x + stripe_width, sx1 - 8), awning_y1, fill=stripe_fill, outline="")
            stripe_index += 1
            x += stripe_width
        self.canvas.create_line(sx0 + 8, awning_y0, sx1 - 8, awning_y0, fill="#d84315", width=2)
        self.canvas.create_line(sx0 + 8, awning_y1, sx1 - 8, awning_y1, fill="#d84315", width=2)

        window_width = 36
        window_height = 32
        window_y0 = awning_y1 + 10
        window_gap = 18
        for idx in range(3):
            wx0 = sx0 + 22 + idx * (window_width + window_gap)
            if wx0 + window_width > sx1 - 22:
                break
            self.canvas.create_rectangle(
                wx0,
                window_y0,
                wx0 + window_width,
                window_y0 + window_height,
                fill="#bbdefb",
                outline="#64b5f6",
                width=2,
            )
            self.canvas.create_line(wx0, window_y0 + window_height / 2, wx0 + window_width, window_y0 + window_height / 2, fill="#64b5f6")
            self.canvas.create_line(wx0 + window_width / 2, window_y0, wx0 + window_width / 2, window_y0 + window_height, fill="#64b5f6")

        door_width = 38
        door_height = 54
        door_x0 = (sx0 + sx1 - door_width) / 2
        door_y0 = sy1 - door_height - 10
        self.canvas.create_rectangle(door_x0, door_y0, door_x0 + door_width, sy1 - 10, fill="#ffe082", outline="#f9a825", width=2)
        self.canvas.create_line(door_x0 + door_width / 2, door_y0, door_x0 + door_width / 2, sy1 - 10, fill="#f9a825", width=2)

        sign_y = sy0 - roof_height + 14
        self.canvas.create_rectangle(
            (sx0 + sx1) / 2 - 58,
            sign_y - 18,
            (sx0 + sx1) / 2 + 58,
            sign_y + 10,
            fill="#1e88e5",
            outline="#1565c0",
            width=2,
        )
        self.canvas.create_text(
            (sx0 + sx1) / 2,
            sign_y - 4,
            text="SUPERMARKET",
            font=("Segoe UI", 11, "bold"),
            fill="#ffffff",
        )

    def _draw_paths(self) -> None:
        self.canvas.create_line(220, 290, 380, 290, fill="#b0bec5", width=6, dash=(8, 6))
        self.canvas.create_line(540, 270, 690, 270, fill="#b0bec5", width=6, dash=(8, 6))

    def _draw_stocks(self) -> None:
        max_display = self.high_stock_threshold
        reorder_point = self.compute_reorder_point()

        self._draw_stock_blocks(self.factory_coords, self.factory_stock, max_display, fill="#66bb6a")
        self._draw_stock_blocks(
            self.warehouse_coords,
            self.warehouse_stock,
            max_display,
            fill="#ffa726",
            safety_stock=self.safety_stock,
            reorder_point=reorder_point,
        )

        factory_flag = self._determine_stock_flag(
            self.factory_stock,
            safety_stock=self.safety_stock,
        )
        warehouse_flag = self._determine_stock_flag(
            self.warehouse_stock,
            safety_stock=self.safety_stock,
            reorder_point=reorder_point,
            high_threshold=self.high_stock_threshold,
        )
        self._draw_flag(self.factory_coords, factory_flag, align="left")
        self._draw_flag(self.warehouse_coords, warehouse_flag, align="right")

        factory_label_x = (self.factory_coords[0] + self.factory_coords[2]) / 2
        warehouse_label_x = (self.warehouse_coords[0] + self.warehouse_coords[2]) / 2
        factory_label_y = self.factory_coords[1] - 18
        warehouse_label_y = self.warehouse_coords[1] - 18

        self.canvas.create_text(
            factory_label_x,
            factory_label_y,
            text=f"{int(self.factory_stock)} units",
            font=("Segoe UI", 11, "bold"),
            fill="#2e7d32",
        )
        self.canvas.create_text(
            warehouse_label_x,
            warehouse_label_y,
            text=f"{int(self.warehouse_stock)} units",
            font=("Segoe UI", 11, "bold"),
            fill="#ef6c00",
        )

    def _draw_score_panel(self) -> None:
        panel_x0, panel_y0 = 760, 36
        panel_x1, panel_y1 = 930, 132

        self.canvas.create_rectangle(
            panel_x0,
            panel_y0,
            panel_x1,
            panel_y1,
            fill="#ffffff",
            outline="#d0d8e0",
            width=2,
        )

        self.canvas.create_text(
            panel_x0 + 12,
            panel_y0 + 12,
            anchor="nw",
            text="Scoreboard",
            font=("Segoe UI Semibold", 12),
            fill="#1c3d5a",
        )

        current_color = "#2e7d32" if self.score >= 0 else "#c62828"
        self.canvas.create_text(
            panel_x0 + 12,
            panel_y0 + 38,
            anchor="nw",
            text=f"Current: {self.score:.0f} pts",
            font=("Segoe UI", 11, "bold"),
            fill=current_color,
        )
        self.canvas.create_text(
            panel_x0 + 12,
            panel_y0 + 62,
            anchor="nw",
            text=f"Best: {self.best_score:.0f} pts",
            font=("Segoe UI", 10),
            fill="#1565c0",
        )
        last_label = "—" if self.run_count <= 1 and math.isclose(self.last_score, 0.0, abs_tol=1e-6) else f"{self.last_score:.0f} pts"
        self.canvas.create_text(
            panel_x0 + 12,
            panel_y0 + 82,
            anchor="nw",
            text=f"Last: {last_label}",
            font=("Segoe UI", 10),
            fill="#6d4c41",
        )

    def _draw_stock_blocks(
        self,
        coords: tuple[int, int, int, int],
        stock: float,
        max_stock: float,
        *,
        fill: str,
        safety_stock: float | None = None,
        reorder_point: float | None = None,
    ) -> None:
        x0, y0, x1, y1 = coords
        width = x1 - x0
        height = y1 - y0
        capacity = max(1.0, max_stock)
        units_per_block = capacity / 30
        block_count = min(30, int(stock / units_per_block))
        safety_blocks = 0
        reorder_blocks = 0
        if safety_stock is not None:
            safety_blocks = min(30, max(0, math.ceil(safety_stock / units_per_block)))
        if reorder_point is not None:
            reorder_blocks = min(30, max(0, math.ceil(reorder_point / units_per_block)))

        cols = 5
        block_size = min(26, width // cols - 4)
        for idx in range(block_count):
            row = idx // cols
            col = idx % cols
            bx0 = x0 + 12 + col * (block_size + 4)
            by1 = y1 - 12 - row * (block_size + 4)
            by0 = by1 - block_size
            if by0 < y0 + 8:
                break
            block_color = fill
            if safety_stock is not None and idx < safety_blocks:
                block_color = "#e53935"
            elif reorder_point is not None and idx < reorder_blocks:
                block_color = "#43a047"
            self.canvas.create_rectangle(bx0, by0, bx0 + block_size, by1, fill=block_color, outline="white", width=1)

    def _determine_stock_flag(
        self,
        stock: float,
        *,
        safety_stock: float | None = None,
        reorder_point: float | None = None,
        high_threshold: float | None = None,
    ) -> str | None:
        if safety_stock is not None and stock <= safety_stock:
            return "red"
        if high_threshold is not None and stock >= high_threshold:
            return "yellow"
        if reorder_point is not None and stock <= reorder_point:
            return "yellow"
        return "green"

    def _draw_flag(self, coords: tuple[int, int, int, int], color: str | None, *, align: str = "center") -> None:
        if not color:
            return
        color_map = {
            "red": "#d32f2f",
            "yellow": "#fbc02d",
            "green": "#388e3c",
        }
        fill = color_map.get(color)
        if not fill:
            return

        x0, y0, x1, y1 = coords
        if align == "left":
            pole_x = x0 - 18
        elif align == "right":
            pole_x = x1 + 18
        else:
            pole_x = (x0 + x1) / 2
        pole_base_y = y0 - 4
        pole_top_y = pole_base_y - 36

        self.canvas.create_line(pole_x, pole_base_y, pole_x, pole_top_y, fill="#546e7a", width=3)
        flag_points = (
            pole_x,
            pole_top_y,
            pole_x + 22,
            pole_top_y + 8,
            pole_x,
            pole_top_y + 16,
        )
        self.canvas.create_polygon(flag_points, fill=fill, outline="#eeeeee", width=1)

    def _draw_worker(self) -> None:
        factory_center = self._rect_center(self.factory_coords)
        warehouse_center = self._rect_center(self.warehouse_coords)
        x = factory_center[0] + (warehouse_center[0] - factory_center[0]) * self.worker_progress
        y = 290
        radius = 14
        body_color = "#ff7043" if self.worker_load > 0 else "#8d6e63"
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=body_color, outline="white", width=2)
        self.canvas.create_rectangle(x - 18, y + radius, x + 18, y + radius + 10, fill="#455a64", outline="")
        if self.worker_load > 0:
            self.canvas.create_text(x, y - 24, text=f"{int(self.worker_load)}", font=("Segoe UI", 9, "bold"), fill="#37474f")

    def _draw_truck(self) -> None:
        warehouse_center = self._rect_center(self.warehouse_coords)
        supplier_center = self._rect_center(self.supplier_coords)
        if self.truck_en_route and self.truck_wait_timer <= 0:
            progress = self.truck_progress
        else:
            progress = 0.0
        x = supplier_center[0] + (warehouse_center[0] - supplier_center[0]) * progress
        y = 270
        self.canvas.create_rectangle(x - 40, y - 18, x + 36, y + 18, fill="#1976d2", outline="white", width=3)
        self.canvas.create_rectangle(x - 30, y - 28, x + 30, y - 8, fill="#42a5f5", outline="white", width=2)
        self.canvas.create_oval(x - 32, y + 20, x - 8, y + 44, fill="#37474f", outline="white", width=2)
        self.canvas.create_oval(x + 6, y + 20, x + 30, y + 44, fill="#37474f", outline="white", width=2)
        if self.truck_en_route:
            if self.truck_wait_timer > 0:
                status = f"Loading... {self.truck_wait_timer:.1f} d"
            elif self.truck_delivery:
                remaining = max(0.0, self.truck_travel_minutes_remaining)
                if remaining >= 1.0:
                    status = f"Delivering {int(self.truck_delivery)} u ({remaining:.1f} d)"
                elif remaining > 0:
                    status = f"Delivering {int(self.truck_delivery)} u ({remaining * 24:.0f} h)"
                else:
                    status = f"Delivering {int(self.truck_delivery)} u"
            else:
                status = "Returning"
            self.canvas.create_text(x, y - 34, text=status, font=("Segoe UI", 9), fill="#1565c0")


    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------
    @staticmethod
    def _rect_center(coords: tuple[int, int, int, int]) -> tuple[float, float]:
        x0, y0, x1, y1 = coords
        return (x0 + x1) / 2, (y0 + y1) / 2

    def run(self) -> None:
        self.root.mainloop()


if __name__ == "__main__":
    InventorySimulatorApp().run()

import os
import re
import pandas as pd # type: ignore
import tkinter as tk
from tkinter import messagebox, filedialog
from tkinter import ttk
import sqlite3
from sqlalchemy import create_engine # type: ignore
from sqlalchemy import text
from datetime import datetime, timedelta
import shutil
import matplotlib.pyplot as plt
import pandas as pd
from sqlalchemy import text
from tkinter import messagebox
import pygame
import win32com.client
from sqlalchemy import types, text
import pandas as pd
import sqlalchemy
from sqlalchemy import create_engine, text
from tkinter import messagebox
import pandas as pd
import sqlite3
from sqlalchemy import create_engine, text, types
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
from datetime import datetime
import subprocess
import pygame
import sqlalchemy
import win32com.client
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

import pandas as pd
import sqlite3
from sqlalchemy import create_engine, text, types
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
from datetime import datetime
import subprocess
import pygame
import sqlalchemy
import win32com.client
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

# Global variables
Data = pd.DataFrame()
Data1 = pd.DataFrame()
BOMData = pd.DataFrame()
ReData = pd.DataFrame()
AltData = pd.DataFrame()
analysis_result = pd.DataFrame()
file_dir = ""

# Define the full path for the SQLite database
db_path = r"C:/Users/ashalaby/OneDrive - Halwani Bros/Planning - Sources/HB DB/sh_HB_planinng_24.db"

# Create the SQLite engine
engine = create_engine(f'sqlite:///{db_path}', echo=False)

# Step 1: Load Data from SQLite Database into DataFrames
def load_Data():
    global Data, Data1, BOMData, ReData, AltData
    Data = pd.read_sql_query("SELECT * FROM RPData", engine)
    Data1 = pd.read_sql_query("SELECT * FROM FGData", engine)
    BOMData = pd.read_sql_query("SELECT * FROM BOMData", engine)
    ReData = pd.read_sql_query("SELECT * FROM ReData", engine)
    AltData = pd.read_sql_query("SELECT * FROM AltData", engine)

def my_sound(sound_name):
    pygame.mixer.init()
    try:
        pygame.mixer.music.load(sound_name)
        pygame.mixer.music.play()
        print(f"Playing sound: {sound_name}")
    except pygame.error as e:
        print(f"Error loading sound file: {e}")

def insert_table_RP():
    file_path = entry1.get()
    
    if not file_path:
        messagebox.showerror("Error", "Please select a file for Table 2")
        return

    try:
        dtype_spec = {"ItemNumber": str}
        df2 = pd.read_excel(file_path, sheet_name="Data", dtype=dtype_spec)
        df2.to_sql(
            'RPData',
            con=engine,
            if_exists='replace',
            index=False,
            dtype={"ItemNumber": sqlalchemy.types.Text()}
        )

        with engine.connect() as conn:
            result = conn.execute(text("SELECT COUNT(*) FROM RPData"))
            row_count = result.fetchone()[0]
        
        messagebox.showinfo("Success", f"Total rows inserted into RPData: {row_count}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to load Table 2: {e}")

def insert_table_hotlist():
    file_path = r"C:/Users/ashalaby/OneDrive - Halwani Bros/Planning - Sources/HB DB/hotlist.xlsx"
    
    if not file_path:
        messagebox.showerror("Error", "Please select a file for Table 2")
        return

    try:
        df2 = pd.read_excel(file_path, sheet_name="Data")
        df2.to_sql('holistData', con=engine, if_exists='replace', index=False)
        
        with engine.connect() as conn:
            result = conn.execute(text("SELECT * FROM holistData"))
            row_count = result.fetchone()
        
        messagebox.showinfo("Success", f"Total rows inserted into Data: {row_count}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to load Table 2: {e}")

def insert_table_BOM():
    file_path = entry3.get()
    
    if not file_path:
        messagebox.showerror("Error", "Please select a file for Table 2")
        return

    try:
        dtype_spec = {"BomVersion_ItemId": str, "ItemId": str}
        required_columns = [
            "BomVersion_ItemId", "Name", "ItemId", "ItemName",
            "ScrapVar", "PmfBatchSize", "BOMQty", "Active"
        ]

        def clean_columns(df):
            df.columns = df.columns.str.strip()
            df.columns = df.columns.str.replace(r"[^0-9a-zA-Z_]", "", regex=True)
            return df

        bom_data = pd.read_excel(file_path, sheet_name='Bom Data', dtype=dtype_spec)
        bom_data = clean_columns(bom_data)

        recipe_data = pd.read_excel(file_path, sheet_name='Recipe Data', dtype=dtype_spec)
        recipe_data = clean_columns(recipe_data)

        missing_bom_cols = [col for col in required_columns if col not in bom_data.columns]
        missing_recipe_cols = [col for col in required_columns if col not in recipe_data.columns]

        if missing_bom_cols or missing_recipe_cols:
            messagebox.showerror(
                "Error", 
                f"Missing columns!\nBOM missing: {missing_bom_cols}\nRecipe missing: {missing_recipe_cols}"
            )
            print("BOM sheet columns:", bom_data.columns.tolist())
            print("Recipe sheet columns:", recipe_data.columns.tolist())
            return

        for df in [bom_data, recipe_data]:
            for col in ["PmfBatchSize", "BOMQty"]:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

        bom_data = bom_data[bom_data["Active"] == "Yes"]
        recipe_data = recipe_data[recipe_data["Active"] == "Yes"]

        bom_data = bom_data[required_columns]
        recipe_data = recipe_data[required_columns]

        bom_data.to_sql('BOMData', con=engine, if_exists='replace', index=False)
        recipe_data.to_sql('ReData', con=engine, if_exists='replace', index=False)

    except Exception as e:
        messagebox.showerror("Error", f"Failed to load Table 2: {e}")
        print("Error details:", e)

def insert_table_FG():
    file_path = entry2.get()
    
    if not file_path:
        messagebox.showerror("Error", "Please select a file for Table 2")
        return

    try:
        df2 = pd.read_excel(file_path, sheet_name="Data")
        df2.to_sql('FGData', con=engine, if_exists='replace', index=False)

        df3 = pd.read_excel(file_path, sheet_name="Data2")
        df3.to_sql('FGData2', con=engine, if_exists='replace', index=False)
        
        with engine.connect() as conn:
            result = conn.execute(text("SELECT COUNT(*) FROM FGData"))
            row_count = result.fetchone()[0]
        
        messagebox.showinfo("Success", f"Total rows inserted into Data: {row_count}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to load Table 2: {e}")
        
def insert_table_Alt():
    file_path = "C:\\Users\\ashalaby\\OneDrive - Halwani Bros\\HB\\follow up SH\\FP follow up 2024.xlsb"
    if not file_path:
        messagebox.showerror("Error", "Please check FP follow up 2024.xlsb address")
        return
    try:
        df2 = pd.read_excel(file_path, sheet_name="AltData", dtype={'ItemNumber': str, 'AltItemNumber': str})
        df2.to_sql('AltData', con=engine, if_exists='replace', index=False)

        with engine.connect() as conn:
            result = conn.execute(text("SELECT COUNT(*) FROM AltData"))
            row_count = result.fetchone()[0]
        
        messagebox.showinfo("Success", f"Total rows inserted into AltData: {row_count}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to insert_table_Alt: {e}")

# ============== NEW: CurAS Functions ==============

def create_CurAS_table():
    """Create CurAS table if it doesn't exist"""
    try:
        with engine.connect() as conn:
            conn.execute(text("""
                CREATE TABLE IF NOT EXISTS CurAS (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    analysis_date DATE NOT NULL,
                    summary_type VARCHAR(50) NOT NULL,
                    
                    category_name VARCHAR(100),
                    product_name VARCHAR(100),
                    item_number VARCHAR(50),
                    
                    total_sales DECIMAL(15,2),
                    total_quantity DECIMAL(15,2),
                    total_transactions INTEGER,
                    
                    performance_status VARCHAR(20),
                    summary_text TEXT NOT NULL,
                    
                    vs_previous_period DECIMAL(10,2),
                    rank_position INTEGER,
                    
                    avg_transaction_value DECIMAL(10,2),
                    
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """))
            conn.commit()
        messagebox.showinfo("Success", "CurAS table created successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to create CurAS table: {e}")

def analyze_and_fill_CurAS():
    """Analyze sales data and fill CurAS table with intelligent summaries"""
    global Data
    
    if Data.empty:
        messagebox.showwarning("Warning", "Please load data first!")
        return
    
    try:
        with engine.connect() as conn:
            conn.execute(text("DELETE FROM CurAS WHERE analysis_date < date('now', '-30 days')"))
            conn.commit()
        
        today = datetime.today().strftime('%Y-%m-%d')
        
        Data['Sales'] = pd.to_numeric(Data['Sales'], errors='coerce').fillna(0)
        Data['SalesValue'] = pd.to_numeric(Data['SalesValue'], errors='coerce').fillna(0)
        Data['Disc'] = pd.to_numeric(Data['Disc'], errors='coerce').fillna(0)
        
        Data['netsales'] = Data['SalesValue'] - Data['Disc']
        
        summaries = []
        
        # Overall Daily Summary
        total_sales_value = Data['netsales'].sum()
        total_qty = Data['Sales'].sum()
        total_trans = len(Data)
        avg_trans_value = total_sales_value / total_trans if total_trans > 0 else 0
        
        performance = "ممتاز" if total_sales_value > 100000 else "جيد" if total_sales_value > 50000 else "متوسط"
        
        summary_text = f"إجمالي المبيعات اليوم: {total_sales_value:,.0f} جنيه من {total_trans} عملية بيع بكمية {total_qty:,.0f} كجم - الأداء: {performance}"
        
        summaries.append({
            'analysis_date': today,
            'summary_type': 'daily_overall',
            'category_name': None,
            'product_name': None,
            'item_number': None,
            'total_sales': total_sales_value,
            'total_quantity': total_qty,
            'total_transactions': total_trans,
            'performance_status': performance,
            'summary_text': summary_text,
            'vs_previous_period': None,
            'rank_position': None,
            'avg_transaction_value': avg_trans_value
        })
        
        # Top 5 Best Selling Products
        if 'ItemName' in Data.columns and 'ItemNumber' in Data.columns:
            top_products = Data.groupby(['ItemNumber', 'ItemName']).agg({
                'netsales': 'sum',
                'Sales': 'sum'
            }).reset_index().sort_values('netsales', ascending=False).head(5)
            
            for idx, row in top_products.iterrows():
                rank = idx + 1
                summary_text = f"المنتج '{row['ItemName']}' في المركز #{rank}: حقق {row['netsales']:,.0f} جنيه بكمية {row['Sales']:,.0f} كجم"
                
                summaries.append({
                    'analysis_date': today,
                    'summary_type': 'top_product',
                    'category_name': None,
                    'product_name': row['ItemName'],
                    'item_number': row['ItemNumber'],
                    'total_sales': row['netsales'],
                    'total_quantity': row['Sales'],
                    'total_transactions': None,
                    'performance_status': 'ممتاز',
                    'summary_text': summary_text,
                    'vs_previous_period': None,
                    'rank_position': rank,
                    'avg_transaction_value': None
                })
        
        # Category Analysis
        if 'Category' in Data.columns:
            category_sales = Data.groupby('Category').agg({
                'netsales': 'sum',
                'Sales': 'sum'
            }).reset_index().sort_values('netsales', ascending=False)
            
            for idx, row in category_sales.iterrows():
                rank = idx + 1
                percentage = (row['netsales'] / total_sales_value * 100) if total_sales_value > 0 else 0
                
                summary_text = f"فئة '{row['Category']}' ساهمت بـ {percentage:.1f}% من المبيعات بقيمة {row['netsales']:,.0f} جنيه"
                
                summaries.append({
                    'analysis_date': today,
                    'summary_type': 'category',
                    'category_name': row['Category'],
                    'product_name': None,
                    'item_number': None,
                    'total_sales': row['netsales'],
                    'total_quantity': row['Sales'],
                    'total_transactions': None,
                    'performance_status': 'جيد' if rank <= 3 else 'متوسط',
                    'summary_text': summary_text,
                    'vs_previous_period': None,
                    'rank_position': rank,
                    'avg_transaction_value': None
                })
        
        # Customer Analysis
        if 'Customer' in Data.columns:
            customer_count = Data['Customer'].nunique()
            avg_per_customer = total_sales_value / customer_count if customer_count > 0 else 0
            
            summary_text = f"تم البيع لـ {customer_count} عميل بمتوسط {avg_per_customer:,.0f} جنيه للعميل الواحد"
            
            summaries.append({
                'analysis_date': today,
                'summary_type': 'customer_analysis',
                'category_name': None,
                'product_name': None,
                'item_number': None,
                'total_sales': total_sales_value,
                'total_quantity': None,
                'total_transactions': customer_count,
                'performance_status': 'جيد',
                'summary_text': summary_text,
                'vs_previous_period': None,
                'rank_position': None,
                'avg_transaction_value': avg_per_customer
            })
        
        # Month Comparison
        if 'Month' in Data.columns:
            Data['Month'] = pd.to_numeric(Data['Month'], errors='coerce')
            current_month = Data['Month'].max()
            previous_month = current_month - 1
            
            current_month_sales = Data[Data['Month'] == current_month]['netsales'].sum()
            previous_month_sales = Data[Data['Month'] == previous_month]['netsales'].sum()
            
            if previous_month_sales > 0:
                change_pct = ((current_month_sales - previous_month_sales) / previous_month_sales) * 100
                trend = "زيادة" if change_pct > 0 else "انخفاض"
                
                summary_text = f"مبيعات الشهر الحالي: {current_month_sales:,.0f} جنيه بـ{trend} {abs(change_pct):.1f}% عن الشهر السابق"
                
                summaries.append({
                    'analysis_date': today,
                    'summary_type': 'monthly_comparison',
                    'category_name': None,
                    'product_name': None,
                    'item_number': None,
                    'total_sales': current_month_sales,
                    'total_quantity': None,
                    'total_transactions': None,
                    'performance_status': 'جيد' if change_pct > 0 else 'يحتاج تحسين',
                    'summary_text': summary_text,
                    'vs_previous_period': change_pct,
                    'rank_position': None,
                    'avg_transaction_value': None
                })
        
        df_summaries = pd.DataFrame(summaries)
        df_summaries.to_sql('CurAS', con=engine, if_exists='append', index=False)
        
        messagebox.showinfo("Success", f"تم إضافة {len(summaries)} تحليل إلى جدول CurAS")
        display_in_treeview(df_summaries)
        
    except Exception as e:
        messagebox.showerror("Error", f"Error in analyze_and_fill_CurAS: {e}")
        print("Error details:", e)

def show_table_CurAS():
    """Display CurAS analysis table"""
    global Data
    try:
        conn = sqlite3.connect(db_path)
        query = "SELECT * FROM CurAS ORDER BY analysis_date DESC, rank_position ASC"
        Data = pd.read_sql_query(query, conn)
        conn.close()
        if not Data.empty:
            display_in_treeview(Data)
        else:
            messagebox.showinfo("Info", "CurAS table is empty. Run analysis first!")
    except Exception as e:
        messagebox.showerror("Error", f"Error loading CurAS: {e}")

# ============== END: CurAS Functions ==============

def browse_file(entry):
    file_path = filedialog.askopenfilename(
        filetypes=[("Excel files", "*.xlsb *.xlsx *.xls")]
    )
    entry.delete(0, tk.END)
    entry.insert(0, file_path)

def export_results():
    global file_dir, analysis_result
    file_dir = os.path.dirname(os.path.abspath(__file__))
    if not analysis_result.empty and file_dir:
        today = datetime.today().strftime('%Y-%m-%d')
        report_type = dropdown.get()
        default_filename = f"{report_type}_{today}.xlsx"
        export_path = os.path.join(file_dir, default_filename)
        
        try:
            analysis_result.to_excel(export_path, index=False, startrow=1)
            wb = load_workbook(export_path)
            ws = wb.active
            ws.auto_filter.ref = ws.dimensions
            last_row = ws.max_row
            last_column = ws.max_column

            numeric_columns = ['OH', 'OH_SC', 'Cur ST', 'Cur AS', 'Cur APP', 'Cur AP',
                'Cur_RST', 'ending_NO_P', 'prod_plan', 'prdo_plan_bom','ending_stock','end_days','plans_ending','plans_end_days','Next RFC',
                'Next OST', 'Next OST Vs RFC','Next PP','AS Vs BP','SS_AS', 'BOMQTY', 'Min Qty', 'remain', 'backlog', 'required_production',
                'SOH_pallet','Cur_RST_pallet','PP_pallet', 'plans_ending_pallet','Next PP_pallet','Last Month Sales','netsales','SalesValue',
                'Disc','Ret','kgprice','Average Sales','Count of Months','Expected Sales','Discount Impact','Vs. Avg Sales','Adjusted Expected Sales',
                'total_sales','total_quantity','total_transactions','avg_transaction_value','vs_previous_period']

            for col_idx in range(1, last_column + 1):
                col_letter = get_column_letter(col_idx)
                formula = f"=SUBTOTAL(9, {col_letter}2:{col_letter}{last_row})"
                ws[f"{col_letter}1"] = formula
                actual_header = ws[f"{col_letter}2"].value
                if actual_header in numeric_columns:
                    for row in range(2, last_row + 1):
                        cell = ws[f"{col_letter}{row}"]
                        cell.number_format = '#,##0'
                    subtotal_cell = ws[f"{col_letter}1"]
                    subtotal_cell.number_format = '#,##0'

            for col in ws.columns:
                max_length = 0
                column = col[0].column_letter
                for cell in col:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = (max_length + 2)
                ws.column_dimensions[column].width = adjusted_width

            ws.freeze_panes = ws['C3']
            wb.save(export_path)

            if os.name == 'nt':
                os.startfile(export_path)
            else:
                subprocess.call(['open', export_path]) if os.name == 'posix' else subprocess.call(['xdg-open', export_path])

            messagebox.showinfo("Success", f"Results exported to {export_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving file: {e}")
    else:
        messagebox.showwarning("No Data", "No analysis results to export or no file directory available")

def show_table_RP():
    global Data
    try:
        conn = sqlite3.connect(db_path)
        query = "SELECT * FROM RPData"
        Data = pd.read_sql_query(query, conn)
        conn.close()
        if not Data.empty:
            display_in_treeview(Data)
        else:
            messagebox.showinfo("Info", "Data table is empty.")
    except Exception as e:
        messagebox.showerror("Error", f"Error loading Data: {e}")

def show_table_BOM():
    global Data
    try:
        conn = sqlite3.connect(db_path)
        query = "SELECT * FROM BOMData"
        Data = pd.read_sql_query(query, conn)
        conn.close()
        if not Data.empty:
            display_in_treeview(Data)
        else:
            messagebox.showinfo("Info", "Data table is empty.")
    except Exception as e:
        messagebox.showerror("Error", f"Error loading Data: {e}")

def show_table_Re():
    global Data
    try:
        conn = sqlite3.connect(db_path)
        query = "SELECT * FROM ReData"
        Data = pd.read_sql_query(query, conn)
        conn.close()
        if not Data.empty:
            display_in_treeview(Data)
        else:
            messagebox.showinfo("Info", "Data table is empty.")
    except Exception as e:
        messagebox.showerror("Error", f"Error loading Data: {e}")

def show_table_FG():
    global Data
    try:
        conn = sqlite3.connect(db_path)
        query = "SELECT * FROM FGData"
        Data = pd.read_sql_query(query, conn)
        conn.close()
        if not Data.empty:
            display_in_treeview(Data)
        else:
            messagebox.showinfo("Info", "Data table is empty.")
    except Exception as e:
        messagebox.showerror("Error", f"Error loading Data: {e}")

def show_table_alt():
    global Data
    try:
        conn = sqlite3.connect(db_path)
        query = "SELECT * FROM AltData"
        Data = pd.read_sql_query(query, conn)
        conn.close()
        if not Data.empty:
            display_in_treeview(Data)
        else:
            messagebox.showinfo("Info", "Data table is empty.")
    except Exception as e:
        messagebox.showerror("Error", f"Error loading Data: {e}")

def show_RP_columns():
    global Data
    try:
        with engine.connect() as conn:
            query = "SELECT * FROM RPData LIMIT 1"
            Data = pd.read_sql_query(query, conn)
            
        column_names = list(Data.columns)
        messagebox.showinfo("Column Names in Data", "\n".join(column_names))
    except Exception as e:
        messagebox.showerror("Error", f"Failed to load columns from Data: {e}")

def display_in_treeview(df):
    global analysis_result
    analysis_result = df
    clear_treeview()
    result_tree["columns"] = list(df.columns)
    result_tree["show"] = "headings"
    for col in df.columns:
        result_tree.heading(col, text=col)
    for index, row in df.iterrows():
        result_tree.insert("", "end", values=list(row))

def copy_excel_range_function():
    excel = win32com.client.Dispatch("Excel.Application")
    excel.Visible = True
    workbook = excel.ActiveWorkbook
    worksheet = excel.ActiveSheet
    messagebox.showinfo("Instructions", "Please select a range in Excel.")
    selected_range = excel.Selection
    selected_values = []
    for row in selected_range:
        row_values = [cell.Value for cell in row]
        selected_values.append(row_values)
    string_array = [', '.join(map(str, row)) for row in selected_values]
    messagebox.showinfo("Selected Range", f"String array:\n{string_array}")
    entry1.insert(0, f"\n{string_array}")
    return string_array

def clear_treeview():
    for item in result_tree.get_children():
        result_tree.delete(item)

def on_function_select(event):
    pass

def run_selected_function():
    selected_function = dropdown.get()
    
    if selected_function == "Load Database":
        load_Data()
    elif selected_function == "Show RP":
        show_table_RP()
    elif selected_function == "Show FG":
        show_table_FG()
    elif selected_function == "Show BOM":
        show_table_BOM()    
    elif selected_function == "Show Re":
        show_table_Re()    
    elif selected_function == "show_table_alt":
        show_table_alt()
    elif selected_function == "Show Column Names in RP":
        show_RP_columns()
    elif selected_function == "Create CurAS Table":
        create_CurAS_table()
    elif selected_function == "Analyze & Fill CurAS":
        analyze_and_fill_CurAS()
    elif selected_function == "Show CurAS":
        show_table_CurAS()
    elif selected_function == "Export Results to Excel":
        export_results()
    else:
        messagebox.showerror("Error", "Unknown function selected!")

# Main UI setup
root = tk.Tk()
root.title("Shalaby\\ Planning Data")

control_frame = tk.Frame(root)
control_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)

dropdown_label = ttk.Label(control_frame, text="Select a Function:")
dropdown_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")

functions = [
    "Load Database", "column_values", "Show RP", "Show BOM", "Show Re", "Show FG", "show_table_alt",
    "Create CurAS Table", "Analyze & Fill CurAS", "Show CurAS",
    "Export Results to Excel" 
]

dropdown = ttk.Combobox(control_frame, values=functions, state="readonly", width=30)
dropdown.grid(row=0, column=1, padx=5, pady=5, sticky="w")

run_button = tk.Button(control_frame, text="Run", command=run_selected_function)
run_button.grid(row=0, column=2, padx=5, pady=5, sticky="w")

range_button = tk.Button(control_frame, text="Range", command=copy_excel_range_function)
range_button.grid(row=0, column=1, padx=5, pady=5, sticky="w")

export_button = tk.Button(control_frame, text="To Excel", command=export_results)
export_button.grid(row=0, column=3, padx=5, pady=5, sticky="w")

entry1 = tk.Entry(control_frame, width=50)
entry1.grid(row=1, column=1, padx=5, pady=5, sticky="w")
entry1.insert(0, "C:/Users/ashalaby/OneDrive - Halwani Bros/Planning - Sources/Planning Modules/Materials.xlsb")

browse_button1 = tk.Button(control_frame, text="Browse", command=lambda: browse_file(entry1))
browse_button1.grid(row=1, column=2, padx=5, pady=5, sticky="w")

load_button1 = tk.Button(control_frame, text="Load RP", command=insert_table_RP)
load_button1.grid(row=1, column=3, padx=5, pady=5, sticky="w")

entry2 = tk.Entry(control_frame, width=50)
entry2.grid(row=2, column=1, padx=5, pady=5, sticky="w")
entry2.insert(0, "C:/Users/ashalaby/OneDrive - Halwani Bros/Planning - Sources/Planning Modules/FP module 23.xlsb")

browse_button2 = tk.Button(control_frame, text="Browse", command=lambda: browse_file(entry2))
browse_button2.grid(row=2, column=2, padx=5, pady=5, sticky="w")

load_button2 = tk.Button(control_frame, text="Load FG", command=insert_table_FG)
load_button2.grid(row=2, column=3, padx=5, pady=5, sticky="w")

entry3 = tk.Entry(control_frame, width=50)
entry3.grid(row=3, column=1, padx=5, pady=5, sticky="w")
entry3.insert(0, "C:/Users/ashalaby/OneDrive - Halwani Bros/Planning - Sources/RECIPE(ver. Dec 2018).XLSX")

browse_button3 = tk.Button(control_frame, text="Browse", command=lambda: browse_file(entry3))
browse_button3.grid(row=3, column=2, padx=5, pady=5, sticky="w")

load_button3 = tk.Button(control_frame, text="Load BOM", command=insert_table_BOM)
load_button3.grid(row=3, column=3, padx=5, pady=5, sticky="w")

# Treeview widget to display results
result_tree = ttk.Treeview(root, height=15)
result_tree.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=10)

# Scrollbar for the Treeview
scrollbar = ttk.Scrollbar(root, orient="vertical", command=result_tree.yview)
result_tree.configure(yscrollcommand=scrollbar.set)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# Auto-load Alt and Hotlist data on startup
insert_table_Alt()
insert_table_hotlist()

# Start the GUI
root.mainloop()